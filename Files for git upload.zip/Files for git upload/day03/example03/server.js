//step 1 load module
const express=require('express');

const app=express();
const port=5657;
const host="127.0.0.1";

//step2 
app.get("/",(req,resp)=>{
    resp.sendfile("./index.html",(err)=>{
            console.log("error reading file");  
    });
    console.log("get completed");
    
});
app.get("/register.html",(req,resp)=>{
    resp.sendfile("./register.html",(err)=>{
            console.log("error reading file");  
    });
    console.log("get completed registration");
    
});
app.get("/login.html",(req,resp)=>{
    resp.sendfile("./login.html",(err)=>{
            console.log("error reading file");  
    });
    console.log("get completed");
    
});
app.post("/register",(req,resp)=>{
    resp.sendfile("./login.html",(err)=>{
            console.log("error reading file");  
    });
    console.log("get completed");
    
});
app.get("/index.html",(req,resp)=>{
    resp.sendfile("./index.html",(err)=>{
            console.log("error reading file");  
    });
    console.log("get completed");
    
});

const bodyparser=require('body-parser');
app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());
app.post("/login",(req,resp)=>{
const userName=req.body.userName;
const password=req.body.password;
if(userName==="sharath" && password==="12345"){
    resp.send("welcome"+userName);
}else{
    resp.send("Invalid");
}
});


// Image
app.get("/images/pic2.jfif",(req,resp)=>{
    resp.sendfile("./images/pic2.jfif");    
});


//step 3
app.listen(port,host,()=>{
    console.log("http://localhost:5656");
})
