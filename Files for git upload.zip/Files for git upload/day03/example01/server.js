//step1 : load module
const express=require('express');
const app=express();
const port=5656;
const host="127.0.0.1";

//step 2 : what to do on request

//a.  text
app.get("/",function(request,response){
    response.send("welcome to express.js!");
});
app.get("/html",function(request,response){
    response.send("<h1>welcome to express.js!</h1>");
});

//step 3 :start server
app.listen(port,host,()=>{
    console.log("http://localhost:5656");
});

