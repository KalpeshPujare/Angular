//step1 : load module
const express=require('express');
const fs=require('fs');
const app=express();
const port=5656;
const host="127.0.0.1";

//step write app.get method to display index.html


app.get("/",(req,resp)=>{
    resp.sendfile("./index.html",(err)=>{
        console.log("error loading file");

    });
    console.log("get completed");



});
  
app.get("/images/pic2.jfif",(req,resp)=>{

    resp.sendfile("./images/pic2.jfif");
});


//step 3 :start server
app.listen(port,host,()=>{
    console.log("http://localhost:5656");
});

