import { Product } from '../product';

export const Prodlist:Product[]=[
{prodId:1,prodName:"penBombasto:" , pizza: 'Veg',price:100,base: 'Thin crust', type: 'Cheese burst'},
{prodId:2,prodName:"Celeritas", pizza: "Veg",price:100,base: "Thin crust", type: "Cheese burst"},
{prodId:2,prodName:"Dynama", pizza: 'Veg',price:100,base: 'Thin crust', type: 'Cheese burst'},
{prodId:2,prodName:"Magneta", pizza: 'Veg',price:100,base: 'Thin crust', type: 'Cheese burst'}
]

// prodId:number;
// prodName:string;
// pizza: string;
// price:number;
// base: string;
// type: string;