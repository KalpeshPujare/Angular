export class Product{
    prodId:number;
    prodName:string;
    pizza: string;
    price:number;
    base: string;
    type: string;

}
