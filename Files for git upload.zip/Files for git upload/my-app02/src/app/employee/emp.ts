export class Employee
{
    empId:number;
    empName:string;
    designation:string;
}