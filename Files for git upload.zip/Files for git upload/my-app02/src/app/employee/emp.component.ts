
import { Component, Input } from '@angular/core';
import { Employee } from './emp';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmployeeComponent {
    @Input()
  emp:Employee={empId:1001,empName:"Sunny",designation:"Trainee"};
}