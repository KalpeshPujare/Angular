import { Component } from '@angular/core';
import { emplist } from './emplist';
import { Employee } from '../emp';

@Component({
  selector: 'app-emplist',
  templateUrl: './emplist.component.html',
  styleUrls: ['./emplist.component.css']
})
export class EmployeeListComponent {
  emplist=emplist;
  selectedEmp:Employee;

  onSelection(emp:Employee)
  {
      this.selectedEmp=emp;
  }
}
