import { Employee } from '../emp';

export const emplist:Employee[]=
[
    {empId:1001,empName:"Bharath",designation:"Trainer"},
    {empId:1002,empName:"Chintu",designation:"Developer"},
    {empId:1003,empName:"Sharath",designation:"Trainee"},
   
]