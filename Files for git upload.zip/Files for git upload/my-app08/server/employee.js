
//step 1 : include your mongoose
const mongoose=require('mongoose');
const Schema=mongoose.Schema;
//step2 : create a collection using schema
var Employee= new Schema({
    empId:{type: Number},
    empName:{type:String},
    designation:{type:String}
},{
    collection:'employee'
});


module.exports=mongoose.model("Employee",Employee)