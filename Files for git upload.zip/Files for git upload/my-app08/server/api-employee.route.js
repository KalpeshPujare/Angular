const express=require('express');
const app=express();
///we are creating api limk for employee
const apiEmpRouter=express.Router();
//we are importing employee schema
let Employee=require('./employee');

//get all employee
apiEmpRouter.route('/allEmp').get((req,resp)=>{
    //resp.send("<h1>Called All emp</h1>");
    //1. get Data from mongodb
    Employee.find((err,data)=>{
      if(err) {
          resp.send("Failure");
      }
      resp.send(data);
    });
});

//get employee by empId
apiEmpRouter.route('/:empId').get((req,resp)=>{
   // resp.send("<h1>Called getby emp</h1>");
   let p_empId=req.params.empId;
   Employee.find({empId:p_empId},(err,data)=>{
    if(err) resp.send("Failed to load data for:"+p_empId);
        resp.send(data);
  });
});

//get employee by empName
apiEmpRouter.route('/ename/:empName').get((req,resp)=>{
   // resp.send("<h1>Called getby EmpName</h1>");
   let p_empName=req.params.empName;
   Employee.find({empName:p_empName},(err,data)=>{
    if(err) resp.send("Failed to load data for:"+p_empName);
        resp.send(data);
  });
});

//add employee 
apiEmpRouter.route('/addEmp').post((req,resp)=>{
    let body_Employee=new Employee(req.body);
    //resp.send(employee);
    body_Employee.save().then(
                ()=>resp.send("New employee added to database"),
                (err)=>resp.send("Failure while adding employee details! ")
    );
});
//delete employee 
apiEmpRouter.route('/delete/:empId').delete((req,resp)=>{
    //resp.send("<h1>Called delete by emp1</h1>");
    let p_empId=req.params.empId;
    Employee.findOneAndDelete({empId:p_empId},(err,data)=>{
        if(err) resp.send("no records found");
        resp.send(data+"deleted records");
    });
});

//update employee
apiEmpRouter.route('/update/:empId/:desig').put((req,resp)=>{
let p_empId=req.params.empId;
let p_desig=req.params.desig;

    //resp.send("<h1>Called update by emp1</h1>");
    Employee.findOneAndUpdate({empId:p_empId},{designation:p_desig},(err,data)=>{
        if(err) resp.send("failed to update");
        resp.send("updated records for "+p_empId+" as "+p_desig);
    });
});

module.exports=apiEmpRouter;