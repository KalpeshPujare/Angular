export class Pizza {
    _id?:number;
    pId:number;
    pName:string;
    pType:string;
    pPrice:number;
    _v?:number;
}
