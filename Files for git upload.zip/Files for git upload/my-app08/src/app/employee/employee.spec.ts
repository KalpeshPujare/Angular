import { Pizza } from './employee';

describe('Employee', () => {
  it('should create an instance', () => {
    expect(new Pizza()).toBeTruthy();
  });
});
