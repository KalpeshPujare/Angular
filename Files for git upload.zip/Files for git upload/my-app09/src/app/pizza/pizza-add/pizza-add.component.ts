import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza-add',
  templateUrl: './pizza-add.component.html',
  styleUrls: ['./pizza-add.component.css']
})
export class PizzaAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
