//declare array
var numbers=[1,2,3,4,5];
//display array
//for ( let index in numbers){
//    console.log(numbers[index]);
//}

var names=["a","b","c","d"];
//for(let index in names){
//    console.log(names[index]);
//}
function display(somearray){
    for(let index in somearray){
        console.log(somearray[index]);
    }
} 
console.log("display numbers");
display(numbers);
console.log("display names");
display(names);