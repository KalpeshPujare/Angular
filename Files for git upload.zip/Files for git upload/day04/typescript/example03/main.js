//method 1 : to create object
//function product(pid,pname,price){
//this.pid=pid;
//this.pname=pname;
//this.price=price;
//this.productDetails=display;
//function display():string {
//    return pid+" "+pname+" "+price;
//}
//}
//create an object of product
//var product1=new product(1,"pepsi",20.00);
//console.log(product1.productDetails()); 
//
//create now an object for book
//function book(bname,bprice,byear){
//  this.bname=bname;
//this.bprice=bprice;
//   this.byear=byear;
//   this.bookDetails=display;
//  function display():string {
//    return bname+" "+bprice+" "+byear;
//}
//}
// 
//  var book2=new book("abcd",150,2000);
//console.log(book2.bookDetails()); 
//method2: to create object using new Object()
var product = new Object();
product.pid = 1;
product.pname = "pepsi";
product.price = 20.0;
product.displayProduct = display;
function display() {
    return this.pid + " " + this.pname + " " + this.price;
}
console.log(product.displayProduct());
