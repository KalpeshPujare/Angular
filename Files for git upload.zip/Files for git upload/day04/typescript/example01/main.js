console.log("welcome to typescript");
var message = "demo of type script";
console.log("@@@@@" + message + "@@@@@");
