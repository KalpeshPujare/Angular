console.log("welcome to typescript");

var message :string="demo of type script";
console.log("@@@@@"+message+"@@@@@");