import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmployeeComponent {
  emp:Employee={empId:1001,empName:"sharath",designation:"trainee"}
}
