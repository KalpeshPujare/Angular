export class  Employee {
     empId:number;
     empName:string;
      designation:string;
    // constructor(empId:number,empname:string,designation:string){
    //     this.empId
    //     this.empName



    // }
    // public getEmpId():number{
    //     return this.empId;
    // }
    // public getEmpName():string{
    //     return this.empName;
    // }
    // public getDesignation():string{
    //     return this.designation;
    // }
    // public setEmpId(empId:number):void{
    //       this.empId=empId;
    // }
    // public setEmpName(empId:string):void{
    //     this.empName=this.empName;
    // }
    // public setDesignation(designation:string):void{
    //     this.designation=designation;
    // }


}