import {Employee}  from '../employee';
export const empList: Employee[] = [
    {empId:1001,empName:"sharath",designation:"employee"},
    {empId:1010,empName:"deepali",designation:"developer"}
];