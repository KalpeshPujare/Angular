import { Component } from '@angular/core';
import { Employee } from '../employee';
import { empList } from './emp-list';

@Component({
  selector: 'app-empList',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmployeelistComponent {
   empList:Employee[]=empList;
}