import { Component } from '@angular/core';
import { Employee } from '../employee';
import { pList } from './product';

@Component({
  selector: 'app-pList',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class productComponent {
   pList:product[]=pList;
}