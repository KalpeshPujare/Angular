
export const pList:product[] = [
    {pId:1001,pName:"mobile",pyear:2000},
    {pId:1010,pName:"watch",pyear:2015}
];