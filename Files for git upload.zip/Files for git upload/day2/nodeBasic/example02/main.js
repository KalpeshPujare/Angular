var calc=require('./calc');
var result=calc.addition(10,10);
console.log("result of addition is : "+result);