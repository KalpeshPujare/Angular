var http=require('http');
var fs=require('fs');
var url=require('url');

var server=http.createServer(function(request,response){
    var urlPath=url.parse(request.url,true);
    var fileName="."+urlPath.pathname;
    console.log("Opening file:"+fileName);
    switch(fileName)
    {
        case './images/download.png':
                loadImage(fileName,response);
            break;
        case './aboutus.html':
            loadhtml(fileName,response);
            break;
        case './contactus.html':
                loadhtml(fileName,response);
                break;
        default:
               loadhtml('./index.html',response);
               break;
    }
});

function loadhtml(fileName,response)
{
    fs.readFile(fileName,function(error,data)
        {
            if(error)
            {
                console.log("Error reading file"+fileName);
            }
            response.setHeader("Content-Type","text/html");
            response.write(data);
            response.end();
        });
}

function loadImage(fileName,response)
{
    fs.readFile(fileName,function(error,data)
        {
            if(error)
            {
                console.log("Error reading file"+fileName);
            }
            response.end(data);
        });
}
const port=5656;
const host="127.0.0.1";
server.listen(port,host,()=>{
    console.log("Server started listening at http://localhost:5656");
});