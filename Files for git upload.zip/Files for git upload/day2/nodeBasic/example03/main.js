var factorial=require('./fact');
var result=factorial.factorial(5);
console.log("result of factorial is : "+result);