//console.log("hello world");
var message="hello world";
for(var index=0;index<10;index++){
    console.log(index+" "+message);
}
alert("welcome");