//step1  Include http module

var http=require('http');
var fs=require('fs');//file system
var url=require('url');
var server=http.createServer(onRequest);

//step2 create httpServer 
function onRequest(request,response){
    //http://localhost:5656/index.html -> /index.html
    var urlPath=url.parse(request.url,true);
    var fileName="."+urlPath.pathname;//=>/index.html
    console.log("opening file : "+fileName);
if(fileName==='./images/pic2.jfif'){
    fs.readFile('./images/pic2.jfif',function(error,data){
        if(error){
            console.log("Error reading file "+fileName);
        }
        response.end(data);      
      });
}
else{
    fs.readFile('./index.html',function(error,data){
        if(error){
            console.log("Error reading file "+fileName);
        }
        response.setHeader('Content-Type','text/html');
        response.write(data);
        response.end();      
      });
    
    

}
}

//step3 assign port,host,callbackfunction

var port=5657;
	var host="127.0.0.1";
	server.listen(port,host,()=>{
		console.log("Server Started at http://localhost:5656");
	});

//step4 1. create html file name as (index.html)
		//2. read file via ( )
		//3. write content in response
		//4. send response to client
		
