//step1  Include http module

var http=require('http');
var fs=require('fs');//file system
var url=require('url');
var server=http.createServer(onRequest);

//step2 create httpServer 

function onRequest(request,response){
	var urlPath=url.parse(request.url,true);
	var fileName="."+urlPath.pathname;//Index.html
	console.log("opening file:"+fileName);
	if(fileName=='./index.html'){
	fs.readFile('./index.html',function(error,data){
		if(error){
			console.log("error reading file"+fileName);
		}
		response.setHeader('Contnt-Type','text/html');
		response.write(data);
		response.end();
	});
}
else{
	fs.readFile('./images/logo.jfif',function(error,data){
	if(error){
		console.log("error reading file"+fileName);
	}
	response.end(data);
});
}
}

//step3 assign port,host,callbackfunction

var port=5656;
	var host="127.0.0.1";
	server.listen(port,host,()=>{
		console.log("Server Started at http://localhost:5656");
	});

//step4 1. create html file name as (index.html)
		//2. read file via ( )
		//3. write content in response
		//4. send response to client
		
