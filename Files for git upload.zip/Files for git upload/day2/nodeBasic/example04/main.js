var http=require('http');
function onRequest(request,response) {
    response.statusCode=200;
    response.setHeader("Content-Type","text/html");

    response.write("<h1>hello world</h1>");
    response.end();
}
//
//http.createServer(onRequest).listen(5656,()=>{

  //  console.log("server started listening at http://localhost:5656");
//}

http.createServer(onRequest).listen(5656,()=>{

     console.log("server started listening at http://localhost:5656");
})