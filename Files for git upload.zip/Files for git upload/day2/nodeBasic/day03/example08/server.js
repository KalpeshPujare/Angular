//step1 : load all modules

const http=require('http');
const url=require('url');
const fs=require('fs');
const server=http.createServer(onRequest);
const port=5656;
const host="127.0.0.1";

//step 2: what server will do 

function onRequest(request,response) {
const urlPath=url.parse(request.url,true);
const fileName=urlPath.pathname;
const query=urlPath.query;
console.log("opening page:"+fileName);

switch(fileName){
    case "/register":

    //read data 
    const FirstName=query.FirstName;

    //verify data 
    //if correct -> go to welcome.html 


    if(FirstName=="unclebob" && LastName==="12345"){
        loadHtml("./welcome.html",response);
    }
    else{
        loadHtml("./error.html",response);
    }
        break;
   default:
        loadHtml("./register.html",response);
        break;
    }
}
function loadHtml(fileName,response) {
    fs.readFile(fileName,(err,data)=>{
      if(err){
          console.log("error loading file"+fileName);
      }
      response.setHeader('Content-Type','text/html');
      response.write(data);
      response.end();
    });
}

//step 3 : start server

server.listen(port,host,()=>{
    console.log("http://"+host+":"+port);
});