export class Employee {
    _id?:number;
    empId:number;
    empName:string;
    designation:string;
    _v?:number;
}
