import { Component } from '@angular/core';
import { bookList } from './book-list';
import { Book } from '../book';


@Component({
    selector: 'app-booklist',
    templateUrl: './book-list.component.html',
    styleUrls: ['./book-list.component.css']
  })
  export class BookListComponent {
   
    booklist=bookList;
    selectedBook:Book;
    
    onSelection(book:Book){
      this.selectedBook=book;
    }
  }
  