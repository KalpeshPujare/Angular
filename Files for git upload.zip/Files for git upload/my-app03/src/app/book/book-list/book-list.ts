
import { Book } from '../book';
export const bookList:Book[]=
[
    {bookId:1001,bookName:"Bharath",price:1000},
    {bookId:1002,bookName:"Chintu",price:100},
    {bookId:1003,bookName:"Sharath",price:50},
   
]