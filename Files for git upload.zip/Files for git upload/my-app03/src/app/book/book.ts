export class Book
{
    bookId:number;
    bookName:string;
    price:number;
}