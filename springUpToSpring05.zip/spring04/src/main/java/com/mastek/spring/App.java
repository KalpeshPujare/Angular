package com.mastek.spring;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mastek.spring.model.Employee;
import com.mastek.spring.service.EmployeeService;

public class App {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("bean.xml");
		EmployeeService empService=context.getBean(EmployeeService.class);
	//display all employees
		List<Employee> empList=empService.findAll();
		empList.forEach(System.out::println);
		
		
	//display Employee details by id
		Employee emp=empService.findById(1001);
		System.out.println(1001+" details "+emp);
		
	//Add Employee
		String msg=empService.addEmp(new Employee(1007,"Ranjeet",200.00,"Executive",20));
		System.out.println(msg);
		System.out.println(empService.findAll().size());
		
	//update employee
		msg=empService.updateEmp(1001, 30000.00);
		System.out.println(msg+" "+empService.findById(1001));
		
	//delete employee	
		msg=empService.deleteEmp(1007);
		empService.findAll().forEach(System.out::println);

	}

}
