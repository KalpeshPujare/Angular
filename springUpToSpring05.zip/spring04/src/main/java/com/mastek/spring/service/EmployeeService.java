package com.mastek.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mastek.spring.model.Employee;

@Service
public class EmployeeService {
	
	private static final List<Employee> empList=new ArrayList<>();
	static {
		empList.add(new Employee(1001,"Manasi",20000.00,"Executive",20));
		empList.add(new Employee(1002,"Aditya",2000.00,"Executive",20));
		empList.add(new Employee(1003,"Tanvi",21000.00,"Executive",20));
		empList.add(new Employee(1004,"Neha",18000.00,"Junior HR",10));
		empList.add(new Employee(1005,"Pallavi",1000.00,"HR Head",10));
		empList.add(new Employee(1006,"Satyendra",10000.00,"Manager",20));
	}
	//get all employees
	public List<Employee> findAll(){
		return empList;
	}
	
	//get Employee by Id
	public Employee findById(int empId) {
		return empList.stream().filter(emp->emp.getEmpId()==empId).findFirst().get();
				
	}
	
	//Add Employee
	public String addEmp(Employee emp) {
		empList.add(emp);
		return "added";
	}
	//Delete Employee
	public String deleteEmp(int empId) {
		if(empList.remove(findById(empId))) {
			return "Deleted";
		}else {
			return "failed";
		}
	}
	//update Employee
	
	public String updateEmp(int empId,double salary) {
		Employee emp=findById(empId);
		emp.setSalary(salary);
		return "Update";
	}

}
