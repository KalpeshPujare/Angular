package com.mastek.spring.config;

public class AppConfig {

}
