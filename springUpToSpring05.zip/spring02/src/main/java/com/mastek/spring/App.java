package com.mastek.spring;

import java.util.stream.Stream;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mastek.spring.model.Order;
import com.mastek.spring.model.OrderItem;
import com.mastek.spring.model.Product;

public class App {
	public static void main(String[] args) {
	
	ApplicationContext context=new ClassPathXmlApplicationContext("bean.xml");
//	//Get p1
//	Product p1=(Product)context.getBean("p1");
//	//Get p2
//	Product p2=(Product)context.getBean("p2");
//	//get p3
//	Product p3=(Product)context.getBean("p3");
//	
//	System.out.println(p1);
//	System.out.println(p2);
//	System.out.println(p3);
//	
	Order order=context.getBean("order1",Order.class);
	System.out.println(order);
	Product p1=new Product(1001,"Italian",250.0);
	System.out.println(p1);
	System.out.println("p1 "+p1.hashCode());
	Product p=context.getBean("p1",Product.class);
	System.out.println("p "+p.hashCode());
	System.out.println("p1==p"+(p1==p));
	System.out.println("p1==p"+(p1.equals(p)));
	
}
}
