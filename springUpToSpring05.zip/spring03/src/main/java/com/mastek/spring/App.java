package com.mastek.spring;

import java.util.stream.Stream;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mastek.spring.model.Order;
import com.mastek.spring.model.OrderItem;
import com.mastek.spring.model.Product;

public class App {
	public static void main(String[] args) {
	
	ApplicationContext context=new ClassPathXmlApplicationContext("bean.xml");
		System.out.println("checking Prototypw");
		
		
		OrderItem item=context.getBean("item1",OrderItem.class);
		System.out.println("OrderItem "+item);
		/*
		 * Order order1=context.getBean("order1",Order.class);
		 * System.out.println(order1); Order
		 * order2=context.getBean("order2",Order.class); System.out.println(order2);
		 */
		/*
		 * System.out.println("order1.getOrderItems().equals(order2.getOrderItems())");
		 * System.out.println(order1.getOrderItems().equals(order2.getOrderItems()));
		 * 
		 * System.out.println("order1.getOrderItems()==(order2.getOrderItems())");
		 * System.out.println(order1.getOrderItems()==(order2.getOrderItems())); for
		 * (OrderItem item1: order1.getOrderItems()) { for (OrderItem item2:
		 * order2.getOrderItems()) { if(item1.equals(item2)) {
		 * System.out.println("From Order1"+item1);
		 * System.out.println("From Order 2"+item2);
		 * System.out.println("item1.equals(item1) "+item1.equals(item2));
		 * System.out.println("item1== (item2)     "+(item1==item2)); }
		 * 
		 * } }
		 */

	}
}
