package com.mastek.spring.model;


import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Order {
	private static final Logger logger =LoggerFactory.getLogger("Order.class");
	private static final String TAG = "### Order ";
	private int orderId;
	private Set<OrderItem> orderItems;
	private transient double totalcost;
	
	
	public Order() {
		super();
		logger.info(TAG+" CONSTRUCTOR CALLED");
	
	}
	
//LifeCycle after your constructor -init()
	void init() {
		logger.info(TAG+" init CALLED ");
		this.totalcost=this.orderItems.stream()
				.mapToDouble(item->item.getProduct().getPrice()*item.getQuantity())
				.sum();
		logger.info(TAG+" init Ended ");	
	}

	
	public Order(int orderId, Set<OrderItem> orderItems, double totalcost) {
	super();
	this.orderId = orderId;
	this.orderItems = orderItems;
	this.totalcost = totalcost;
}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Set<OrderItem> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(Set<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

	public double getTotalcost() {
		return totalcost;
	}

	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + orderId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (orderId != other.orderId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderItems=" + orderItems + ", totalcost=" + totalcost + "]";
	}

	public void destroy() {
		logger.info(TAG+" Destruction started .....");
	}
	
	
}
