package com.mastek.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mastek.spring.model.User;

public class App {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		
		
		User user1=context.getBean(User.class);
		
		
		System.out.println("Bean Factor created: "+user1);
		User user2=(User) context.getBean("user1");
		System.out.println("Bean Factor created"+user2);
		
		if(user1==user2) {
			System.out.println("equals");
		}else {
			System.out.println("Different");
		}
	}

}
