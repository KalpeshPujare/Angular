import { Component, OnInit, Input } from '@angular/core';
import { Pizza } from '../pizza';
import { ActivatedRoute } from '@angular/router';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-pizza-edit',
  templateUrl: './pizza-edit.component.html',
  styleUrls: ['./pizza-edit.component.css']
})
export class PizzaEditComponent implements OnInit {
  @Input()
  pizza:Pizza[];
  constructor(private route:ActivatedRoute,private service:PizzaService) { }

  ngOnInit() {
  }
  editPizza(pizzaId:any,pizzaPrice:any){
    this.service.editPizza(pizzaId,pizzaPrice);
  }

}
