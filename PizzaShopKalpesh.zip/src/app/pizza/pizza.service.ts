import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Pizza } from './pizza';


@Injectable({
  providedIn: 'root'
})
export class PizzaService {
  editPizza(pizzaId,pizzaPrice):any {
    return this.httpClient.put(`${this.uri}`+'/edit/'+pizzaId+'/'+pizzaPrice,{})//////////////////////////////////////
    .subscribe(res=>console.log(pizzaId+" edit from database"));
  }

 
  deletePizza(pizzaId:number):any {
    
      
    
    return this.httpClient.delete(`${this.uri}`+'/delete/'+`${pizzaId}`)
    .subscribe(res=>console.log("Pizza is Deleted"));
    
  }
////////////////////////////////////////////////////
orderPizza(pizzaId:number):any{
return this.httpClient.get(`${this.uri}`+'/order/'+`${pizzaId}`)
    .subscribe(res=>console.log("Pizza is Ordered"));
}

   //Default URI to call express service is :http://localhost:4000/pizza
  uri='http://localhost:4000/pizza';

  constructor(private httpClient:HttpClient) { }
  
  getPizzas():Observable<Pizza[]>{
    return this.httpClient.get<Pizza[]>(`${this.uri}`+'/allPizza');
  }
///////////////////////////////////////////////////
  addPizza(id,name,price){
    let pizza={
      pizzaId:id,
      pizzaName:name,
      pizzaPrice:price
    };
    return this.httpClient.post(`${this.uri}`+'/addPizza',pizza)
    .subscribe(res=>console.log("New Employee registered successfully"));
  }

  
}
