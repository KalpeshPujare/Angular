import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Pizza } from '../pizza';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-pizza-get',
  templateUrl: './pizza-get.component.html',
  styleUrls: ['./pizza-get.component.css']
})
export class PizzaGetComponent implements OnInit {
  pizzas:Pizza[];
  selectedPizza: Pizza;

  constructor(private route:ActivatedRoute,private service:PizzaService) { }

  ngOnInit() {
    this.service.getPizzas()
    .subscribe(pizzaList=>this.pizzas=pizzaList);
  }
  onSelection(pizza:Pizza){
    this.selectedPizza=pizza;
  }

}
