export class Pizza{
    _id?:number;
    pizzaId:number;
    pizzaName:string;
    pizzaPrice:number;
    _v?:number;
}