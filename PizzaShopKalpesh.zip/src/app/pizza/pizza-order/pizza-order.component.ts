import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PizzaService } from '../pizza.service';
import { Pizza } from '../pizza';

@Component({
  selector: 'app-pizza-order',
  templateUrl: './pizza-order.component.html',
  styleUrls: ['./pizza-order.component.css']
})
export class PizzaOrderComponent implements OnInit {
  pizzas:Pizza[];
  selectedPizza: Pizza;

  constructor(private route:ActivatedRoute,private service:PizzaService) { }

  ngOnInit() {
    this.service.getPizzas()
    .subscribe(pizzaList=>this.pizzas=pizzaList);
  }
  onSelection(pizza:Pizza){
    this.selectedPizza=pizza;
  }
  onSelect(pizza:Pizza):void{
    this.selectedPizza=pizza

  }

}
