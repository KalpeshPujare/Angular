import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PizzaComponent } from './pizza/pizza.component';
import { PizzaAddComponent } from './pizza/pizza-add/pizza-add.component';

import { PizzaDeleteComponent } from './pizza/pizza-delete/pizza-delete.component';
import { PizzaGetComponent } from './pizza/pizza-get/pizza-get.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule} from '@angular/forms'
import { ReactiveFormsModule} from '@angular/forms';
import { PizzaEditComponent } from './pizza/pizza-edit/pizza-edit.component';
import { PizzaOrderComponent } from './pizza/pizza-order/pizza-order.component';
@NgModule({
  declarations: [
    AppComponent,
    PizzaComponent,
    PizzaAddComponent,
    PizzaEditComponent,
    PizzaDeleteComponent,
    PizzaGetComponent,
    PizzaOrderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
