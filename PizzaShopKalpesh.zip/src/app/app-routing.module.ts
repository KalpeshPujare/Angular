import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PizzaAddComponent } from './pizza/pizza-add/pizza-add.component';
import { PizzaDeleteComponent } from './pizza/pizza-delete/pizza-delete.component';
import { PizzaEditComponent } from './pizza/pizza-edit/pizza-edit.component';
import { PizzaOrderComponent } from './pizza/pizza-order/pizza-order.component';

const routes: Routes = [
  {path:'pizza/create',component:PizzaAddComponent},
  {path: 'pizza/delete/:pizzaId',component:PizzaDeleteComponent},
  {path:'pizza/edit/:pizzaId/:pizzaPrice',component:PizzaEditComponent},
  {path:"pizza/order/:pizzaId",component:PizzaOrderComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
