const express=require('express');
const app=express();
// we are creating api link for pizza
const apiPizzaRouter=express.Router();
// we are importing pizza schema
let Pizza=require('./pizza');
//get all pizza
apiPizzaRouter.route('/allPizza').get((req,resp)=>{
    // resp.send("<h1>Called all pizza</h1>");
    Pizza.find((err,data)=>{
        if (err){
            resp.send("Failed to load data for:"+p_pizzaId);
        }
        resp.send(data);
    });
});
//get pizza by pizzaId
apiPizzaRouter.route('/:pizzaId').get((req,resp)=>{
    let p_pizzaId=req.params.pizzaId;
    // resp.send("<h1>Called getby pizzaId</h1>");
    Pizza.find({pizzaId:p_pizzaId},(err,data)=>{
        if (err){
            resp.send("Failed to load data for:"+p_pizzaId);
        }
        resp.send(data);
    });

});

//get pizza by pizzaName
apiPizzaRouter.route('/pname/:pizzaName').get((req,resp)=>{//////////////////////////////////////////////
    let p_pizzaName=req.params.pizzaName;
    Pizza.find({pizzaName:p_pizzaName},(err,data)=>{
        if(err){
            resp.send("Failed to load data from"+p_pizzaName)
        }
        resp.send(data);
    });
   
});

//add pizza
apiPizzaRouter.route('/addPizza').post((req,resp)=>{
    let body_pizza= new Pizza(req.body);
    //  resp.send(pizza);
    body_pizza.save().then(
        ()=>resp.send("New Pizza added to database"),
        (err)=>resp.send("Failure while adding pizza details")
    );

});

//delete pizza
apiPizzaRouter.route('/delete/:pizzaId').delete((req,resp)=>{
    let p_pizzaId=req.params.pizzaId;
    // resp.send("<h1>Called delete by pizzaId</h1>");
    Pizza.findOneAndDelete({pizzaId:p_pizzaId},(err,data)=>{
        if(err) resp.send("Failed to delete"+p_pizzaId);
        
        resp.send(data+"deleted");
    });
});

//order Pizza
apiPizzaRouter.route('/order/:pizzaId').get((req,resp)=>{
    let p_pizzaId=req.params.pizzaId;
    //rep.send("<h2>Called ordered by pizzaId</h1>");
    Pizza.find({pizzaId:p_pizzaId},(err,data)=>{
        if (err){
            resp.send("Failed to load data for:"+p_pizzaId);
        }
        resp.send(data);
    });


});



//update pizza
apiPizzaRouter.route('/edit/:pizzaId/:pizzaPrice').put((req,resp)=>{
    // resp.send("<h1>Called edit by pizzaId</h1>");
    let p_pizzaId=req.params.pizzaId;
    let p_pizzaPrice=req.params.pizzaPrice;

    Pizza.findOneAndUpdate({pizzaId:p_pizzaId},{pizzaPrice:p_pizzaPrice},(err,data)=>{
        if (err) resp.send("Failed to edit");
        resp.send("Edit records for"+p_pizzaId+"as"+p_pizzaPrice);
    });
}
);

module.exports=apiPizzaRouter;