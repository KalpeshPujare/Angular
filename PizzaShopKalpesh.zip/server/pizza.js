//step1: include mongoose
const mongoose=require('mongoose');
const Schema=mongoose.Schema;
//step2: create a collection using Schema
// mongoose allow us to work with collecyion of object
// it acts as an ORM
// new Schema ({attributes in documents}),{name of collection}
let Pizza=new Schema({
    pizzaId:{type:Number},
    pizzaName:{type:String},
    pizzaPrice:{type:Number}
},{
    collection:'pizza'//it shows in which collection it can be found
});
//to access your document created in mongodb as an object
//we call mongoose.model("Pizza",Pizza);
//Pizza is Schema
// and the mongoose.model convert the collection of schema into object
module.exports=mongoose.model("Pizza",Pizza);