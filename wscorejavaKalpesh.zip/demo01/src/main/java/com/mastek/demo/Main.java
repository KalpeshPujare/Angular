package com.mastek.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.mastek.demo.model.Order;
import com.mastek.demo.model.Product;

public class Main {

	public static void main(String[] args) {
		
//		oldjdbc();
		try {
			Configuration configuration = new Configuration();
			configuration.configure("hibernate.cfg.xml");
			ServiceRegistry serviceRegistry = configuration.getStandardServiceRegistryBuilder().build();
			SessionFactory factory = configuration.buildSessionFactory(serviceRegistry);
			Session session = factory.getCurrentSession();
			Transaction transaction = session.beginTransaction();
			session.persist(new Product("P1001", "Pepsi", 200.00));
			transaction.commit();
			session.persist(new Order("O1001",LocalDate.now(),LocalDate.now()));
			System.out.println("Product"+session.get(Product.class, "P1002"));
			System.out.println("Order"+session.get(Order.class, "O1001"));
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}

	}

	private static void oldjdbc() {
		final String URL="jdbc:mysql://localhost:3306/mastekdb";
		final String USERNAME="root";
		final String PASSWORD="root";
		
		
		
		//step1: create connection
		try {
			
		Connection con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
		if(con.isClosed()) {
		System.out.println("Error to build connection");
		}else {
		System.out.println("connected successfully");
		} 
		con.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
