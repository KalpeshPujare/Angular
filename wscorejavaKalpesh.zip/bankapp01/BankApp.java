package com.mastek.bankapp;
//Default package for java : java.lang
import java.util.Scanner;

import com.mastek.bankapp.model.BankAccount;
//ctrl+f11    -    execute
//ctrl+shift+s- to save all
public class BankApp {

	public static void main(String[] args) {
		Object account =new BankAccount(1001,"Mr.Joshi",89000);
		//sysout+ctrl+space ->System.out.println();
//		System.out.println(account.getAccNo());
//		System.out.println(account.getAccName());
//		System.out.println(account.getBalance());
//		System.out.println(account);
//		System.out.println(((BankAccount)account).deposit(10000.00));
		Scanner scanner=new Scanner(System.in);
		while(true){
		System.out.println("Choose Operation");
		System.out.println("1.Deposit");
		System.out.println("2.Withdraw");
		//Accepting string data and converting into primitive
		//using wrapper class
		int option = Integer.parseInt(scanner.nextLine());
		BankAccount ba=(BankAccount)account;
		switch(option){
		case 1:
				System.out.println("Enter Deposit amount");
				double amount=Double.parseDouble(scanner.nextLine());
				System.out.println("Available balance is :"+ba.deposit(amount));
				break;
		case 2:
				System.out.println("Enter Withdraw amount");
				 amount=Double.parseDouble(scanner.nextLine());
				 
				System.out.println("Available balance is :"+ba.withdraw(amount));
				 System.out.println(amount+"debited from your account");
				break;		
		default:
				System.out.println("Choose correct option");
				break;
			}
					System.out.println("Do you want to continue? y/n");
					String choice=scanner.nextLine();
					if(choice.equalsIgnoreCase("n")){
						break;
					}
		}
		scanner.close();
		
		
		}
		
		
	}

