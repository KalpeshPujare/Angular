public class GreetingApp{
	//Which starts your application
	public static void main(String[] args){
		Greeting greeting=new Greeting();
		System.out.println("\n"+greeting.greet("to java"));
	
	
	//good morning jatin
	greeting.setMessage("Good Morning ");
	System.out.println("\n"+greeting.greet("jatin"));
	System.out.println("\n"+greeting.greet("surabhi"));
	
	}
}