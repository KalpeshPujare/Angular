//basic of java
//file name==public class name
//

public class Greeting{
	private String message="Welcome !\n";
	 
	 public Greeting(){}
	 
	public String getMessage(){
		return this.message;
	}
	
	public void setMessage(String message){
		this.message=message;
	}
	
	public String greet(String customMessage){
		return this.message+""+customMessage;
	}

}