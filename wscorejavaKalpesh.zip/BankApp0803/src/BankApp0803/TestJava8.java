package BankApp0803;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class TestJava8 {

	public static void main(String[] args) {
		//Function<T,R>
		Function<String, String> myFunction=s->s.toLowerCase();
		System.out.println(myFunction.apply("DHANASHREE"));
		myFunction=s->s.toUpperCase();
		System.out.println(myFunction.apply("dhanashree"));
		
		myFunction=String::toLowerCase;
		System.out.println(myFunction.apply("DHANASHREE"));
		
		System.out.println("use consumer");
		
		Consumer<String> c=s->System.out.println(s);
		c.accept("Welcome to Consumer");
			c=System.out::println;
			c.accept("using::");
			
			System.out.println("use Predicate");
			Predicate<String> p1=s->s.length()<16;
			Predicate<String> p2=s->s.length()>8;
			//String must be 
			Predicate<String> p3=p1.and(p2);
			System.out.println("p3.test(\"dhanashree\")"+p3.test("dhanashree"));
			System.out.println("p3.test(\"dhanashree\")"+p3.test("dhana"));
			
			Predicate<String> p4=Predicate.isEqual("admin");
			System.out.println("p4.test(\"admin\")"+p4.test("admin"));
			System.out.println("p4.test(\"Admin\")"+p4.test("Admin"));
			
	}

}
