package BankApp0803;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BinaryOperator;

public class TestJava8Streams {

	public static void main(String[] args) {
		List<Person> listOfPerson=new ArrayList<>();
		listOfPerson.add(new Person("MJ",23));
		listOfPerson.add(new Person("DJ",21));
		listOfPerson.add(new Person("SJ",20));
		listOfPerson.add(new Person("JK",23));
		listOfPerson.add(new Person("GV",38));
		listOfPerson.add(new Person("TV",33));
		
		//we want to calculate the average age of people having age>20
//		Consumer<Person> c1=p->listOfPerson.add(p);
//		Consumer<Person> c2=System.out::println;
//		Consumer<Person> c3=c1.andThen(c2);
//		c3.accept(new Person("javed jaffry",45));
		
		
		System.out.println("Using Stream");
//		Stream<Person> stream=listOfPerson.stream();
//		Stream<Person> filter=stream.filter(p->p.age>20);
//		filter.forEach(System.out::println);
//		
		System.out.println("clubbing it in one line");
		listOfPerson.parallelStream().filter(p->p.age>20).forEach(System.out::println);
		
		System.out.println("result of peek");
		
		List<Person> result=new ArrayList<Person>();
		listOfPerson.stream()
					.filter(p->p.age>20)
					.peek(p->result.add(p))
					.forEach(System.out::println);
		
		List<Integer> ageGT20=new ArrayList<>();
//			Stream s1=listOfPerson.stream()
//					.filter(p->p.age>20)
//					.map(p->p.age);
			BinaryOperator<Integer> sum=(i1,i2)->i1+i2;
			Integer id=0;
//			System.out.println(s1.reduce(id, sum));
			
			Integer result1=listOfPerson.stream()
							.filter(p->p.age>20)
							.map(p->p.age)
							.reduce(id,sum);
			System.out.println("sum is"+result1);
			System.out.println("average of age"+listOfPerson.stream()
								.filter(p->p.age>20)
								.mapToInt(p->p.age)
								.average());
	}


	

}
class Person{
	String name;
	int age;
	public Person(String name, int age) {
		super();
		this.name= name;
		this.age= age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}