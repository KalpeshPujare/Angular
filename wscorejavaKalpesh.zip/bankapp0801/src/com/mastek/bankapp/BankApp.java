package com.mastek.bankapp;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.SalaryAccount;
import com.mastek.bankapp.model.SavingAccount;
import com.mastek.bankapp.service.BankAccountCollection;

public class BankApp {

	
	public static void main(String[] args) {
		
		//step1: Create account
		//step2: accept accNo and do transaction
		//step3: exit
		BankAccount saving=new SavingAccount("Jatin", 11111);
		BankAccount salary=new SalaryAccount("Nitin", 11112);
		BankAccountCollection collection = new BankAccountCollection();
		collection.add(saving);
		collection.add(salary);
		List<BankAccount> listOfAccount=collection.findAll();
		for(BankAccount account:listOfAccount) {
			System.out.println(account);
		}
		//using Iterator
		System.out.println("Using Iterator");
		Iterator<BankAccount> iterator=listOfAccount.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
			
		}
		//using ListIterator
		ListIterator<BankAccount> listIterator=listOfAccount.listIterator();
		System.out.println("ListIterator.hasnext() and next()");
		
		while(listIterator.hasNext()) {
		System.out.println(listIterator.next());
		listIterator.add(new SavingAccount("nextCalled",0));
		}
		System.out.println("ListIterator.hasPrevious() and previous()");
		while(listIterator.hasPrevious()) {
			System.out.println(listIterator.previous());
//			collection.add(new SavingAccount("ranjit",0));
//			listIterator.add(new SavingAccount("prevcalled",0));
		}
		
		
		
		
		//Getting specific object using account number
		BankAccount account=collection.findByAccNo(1);
		System.out.println(account);
		
		

		
	}

	
}