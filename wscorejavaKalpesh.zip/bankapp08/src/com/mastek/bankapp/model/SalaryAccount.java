package com.mastek.bankapp.model;

import com.mastek.bankapp.util.InsufficientBalanceException;

public class SalaryAccount extends BankAccount {

//	public SalaryAccount() {
//		super();
//		// TODO Auto-generated constructor stub
//	}

	public SalaryAccount(int accNo, String accName, double balance) {
		super(accNo, accName, balance);
		// TODO Auto-generated constructor stub
	}
	
	
	public SalaryAccount(String accName, double balance) {
		super(accName, balance);
		// TODO Auto-generated constructor stub
	}


	@Override
	public double withdraw(double amount) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		double diff=this.balance-amount;
		if (diff>=0) {
			this.setBalance(diff);
		}else {
			throw new InsufficientBalanceException("Insufficient Balance");
		}
		return this.getBalance();
	}
}
