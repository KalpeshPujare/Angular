package com.mastek.bankapp.service;

import java.util.ArrayList;
import java.util.List;

import com.mastek.bankapp.model.BankAccount;

public class BankAccountCollection implements ICollection{

	private static final List<BankAccount> listAccounts=
			new ArrayList<BankAccount>();
	@Override
	public String add(BankAccount account) {
		if(listAccounts.contains(account)) {
			return "PRESENT";
		}
		listAccounts.add(account);
		return "CREATED";
	}

	@Override
	public List<BankAccount> findAll() {
		
		return listAccounts;
	}

	@Override
	public BankAccount findByAccNo(int accNo) {
		for(BankAccount account:listAccounts) {
			if(account.getAccNo()==accNo) {
				return account;
			}
		}
		return null;
	}

}