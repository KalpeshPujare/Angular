package com.mastek.bankapp.service;

import java.util.List;

import com.mastek.bankapp.model.BankAccount;

public interface ICollection {
	
	String add(BankAccount account); //adding new account
	List<BankAccount> findAll();  // find all account
	BankAccount findByAccNo(int accNo);   //getting specific account by accno.
}
