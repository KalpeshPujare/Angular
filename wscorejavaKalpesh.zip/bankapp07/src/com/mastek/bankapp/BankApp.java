package com.mastek.bankapp;

import java.util.Scanner;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.SalaryAccount;
import com.mastek.bankapp.model.SavingAccount;
import com.mastek.bankapp.model.Transaction;

public class BankApp {

	private static BankAccount[] accounts = new BankAccount[2];
	static {
		accounts[0] = new SavingAccount(1001, "Ajit", 20_000.00);
		accounts[1] = new SalaryAccount(1002, "Sujit", 20_000.00);
	}

	public static void main(String[] args) {

		// step1: Ask Account Number
		// step2: Ask operation
		// Step3: display operation result
		Scanner scanner = new Scanner(System.in);
		BankAccount account = null;
		double amount=0.0;
		String msg="";
		while (true) {
			System.out.println("Enter account number ");
			int accNo = Integer.parseInt(scanner.nextLine());
			account = getAccountByAccNo(accNo);			
			if (account != null) {				
				final Transaction transaction=new Transaction(account);				
				System.out.println("Select :\n1.Withdraw \n2.Deposit ");
				final String operation = scanner.nextLine();				
				switch (operation) {
				case "1":
					System.out.println("Enter amount to be debited");
					amount=Double.parseDouble(scanner.nextLine());
					try {
						msg=transaction.withdraw(amount);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				case "2":
					System.out.println("Enter amount to be credited");
					amount=Double.parseDouble(scanner.nextLine());
					msg=transaction.deposit(amount);
					break;
				default:
					break;
				}
				System.out.println(msg);
			} else {
				System.out.println("No such account exist!");
			}

			System.out.println("Do you want to continue y/n");
			String choice = scanner.nextLine();
			if (choice.equalsIgnoreCase("N")) {
				break;
			}
		}
		scanner.close();
	}

	private static BankAccount getAccountByAccNo(int accNo) {
		for (BankAccount account : accounts) {
			if (account.getAccNo() == accNo) {
				return account;
			}
		}
		return null;
	}

}