package threadComm02;

public class Eater extends Thread {
	private FoodItem foodItem;
	
	public Eater(FoodItem foodItem) {
		super();
		this.foodItem = foodItem;
	}
	@Override
	public void run() {
		for(String dishName:foodItem.getFoods()) {
			try {
				foodItem.eat(dishName);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException(e.getMessage());
			}
			
		}
		
	}
	

}
