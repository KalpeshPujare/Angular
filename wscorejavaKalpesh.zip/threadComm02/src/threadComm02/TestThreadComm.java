package threadComm02;

public class TestThreadComm {

	public static void main(String[] args) {
		
		FoodItem foodItem=new FoodItem();
		Eater eater=new Eater(foodItem);
		Waiter waiter=new Waiter(foodItem);
		
		eater.start();
		waiter.start();

	}

}
