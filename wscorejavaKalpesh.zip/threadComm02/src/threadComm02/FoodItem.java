package threadComm02;

public class FoodItem {
		private boolean isServed=false;
	private String [] foods= new String[]{"vada pav","Misal pav","Pani Puri","Samosa"};
// alt s r
	public String[] getFoods() {
		return foods;
	}
	
	public synchronized void eat(String dishName) throws InterruptedException{
		if(isServed) {
			System.out.println("Eating-"+dishName);
			isServed=false;
			notify();
			
		}else 
			wait();
	
	}
	
	public synchronized void serve(String dishName) throws InterruptedException{
		if(!isServed) {
			System.out.println("Served Food "+dishName);
			isServed=true;
			notify();
		}else 
		wait();
		}

	public void setFoods(String[] foods) {
		this.foods = foods;
	}


	
	
	
}
