package threadComm02;

import java.util.concurrent.TimeUnit;

public class Waiter extends Thread{
	private FoodItem foodItem;
	
	public Waiter(FoodItem foodItem) {
		super();
		this.foodItem = foodItem;
	}
	
	@Override
	public void run() {
		for(String dishName:foodItem.getFoods()) {
			try {
				foodItem.serve(dishName);
				TimeUnit.MILLISECONDS.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException(e.getMessage());
			}
			
		}
		
		
		
	}
	
}
