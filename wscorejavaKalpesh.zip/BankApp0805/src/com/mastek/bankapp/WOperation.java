package com.mastek.bankapp;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.Transaction;

public class WOperation extends Thread {
	private BankAccount account;
	private double amount;
	public WOperation(BankAccount account,double amount) {
		super();
		this.account = account;
		this.amount = amount;
	}
	
	@Override
	public void run() {
		final Transaction t1=new Transaction(account);
		try {
			t1.withdraw(amount);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
			
		}
		
	}
	
	
}
