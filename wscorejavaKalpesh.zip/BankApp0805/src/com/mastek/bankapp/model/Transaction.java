package com.mastek.bankapp.model;

public class Transaction {
	private BankAccount account;
	
	public Transaction(BankAccount account) {
		super();
		this.account = account;
		
	}
	
	public String withdraw(double amount)throws Exception{
		return amount+" debited from "+account.getAccNo()+"\n available balance is "+account.withdraw(amount);
	}
	
	public  String deposit(double amount) {
		
		return amount+" credited to "+account.getAccNo()+"\n available balance is "+account.deposit(amount);
	}

}
