package com.mastek.bankapp.model;

import com.mastek.bankapp.util.InsufficientBalanceException;

public abstract class BankAccount implements Comparable<BankAccount> {
	
	private static int counter=0;
	private int accNo;
	private String accName;
	protected double balance;
	//default constructor
	private BankAccount() {
		super();
		
	}
	
	//overload alt s a
	public BankAccount( String accName, double balance) {
		super();
		this.accNo = ++counter;
		this.accName = accName;
		this.balance = balance;
	}
	// alt s a
		public BankAccount(int accNo, String accName, double balance) {
			super();
			this.accNo=accNo;
			this.accName = accName;
			this.balance = balance;
		}

	//getter alt s r
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	//tostring() alt s s s
	@Override
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", accName=" + accName + ", balance=" + balance + "]";
	}
	
	
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankAccount other = (BankAccount) obj;
		if (accNo != other.accNo)
			return false;
		return true;
	}
	
	
	
	//alt s v 
	
	@Override
	public int compareTo(BankAccount o) {
		// TODO Auto-generated method stub
		return this.accNo-o.accNo;
	}

	// Business Logic
	public synchronized double deposit(double amount){
		System.out.println("before Current available balace is "+getBalance());
		this.balance= this.balance+amount;
		System.out.println("after deposit"+getBalance());
		return getBalance();
	}

	//to import all classes from the other package shortcut : ctrl shift o
	public abstract double withdraw(double amount)throws InsufficientBalanceException;

}


