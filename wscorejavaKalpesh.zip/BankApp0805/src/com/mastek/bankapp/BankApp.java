package com.mastek.bankapp;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.SavingAccount;

public class BankApp {

	public static void main(String[] args) {
	
		BankAccount account=new SavingAccount(1001,"Ajit",10000);
		
//		Transaction transaction01=new Transaction(account);
//		Transaction transaction02=new Transaction(account);
//		Transaction transaction03=new Transaction(account);
//		
//		
//		
//		
//		transaction01.deposit(10000);
//		System.out.println("current balace : "+account.getBalance());
//		transaction02.deposit(10000);
//		System.out.println("current balance"+account.getBalance());
//		transaction03.deposit(10000);
//		System.out.println("current balance"+account.getBalance());
//		
		Operation operation1=new Operation(account,10000);
		Operation operation2=new Operation(account,10000);
		Operation operation3=new Operation(account,10000);
		
		operation1.start();
		operation2.start();
		operation3.start();
		
		
		WOperation woperation1=new WOperation(account,1000);
		WOperation woperation2=new WOperation(account,1000);
		WOperation woperation3=new WOperation(account,1000);
		
		woperation1.start();
		woperation2.start();
		woperation3.start();
		
	}

	
	

}