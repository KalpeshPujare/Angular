package com.mastek.bankapp;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.Transaction;

public class Operation extends Thread {
	
	private BankAccount account;
	private double amount;
	public Operation(BankAccount account,double amount) {
		super();
		this.account = account;
		this.amount = amount;
	}
	@Override
	public void run() {
		final Transaction t1=new Transaction(account);
		
		final String msg=t1.deposit(amount);
	
	}
}
