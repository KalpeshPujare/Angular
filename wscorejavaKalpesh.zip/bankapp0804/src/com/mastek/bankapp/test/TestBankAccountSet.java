package com.mastek.bankapp.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.mastek.bankapp.model.SavingAccount;
import com.mastek.bankapp.service.BankAccountCollection;

class TestBankAccountSet {
	private static BankAccountCollection collection;

	@BeforeAll
	static void beforeAll(){
		collection=new BankAccountCollection();	
	}

	@AfterAll
	static void afterAll() {
		System.out.println("Release resources used");
		collection=null;
	}

	@BeforeEach
	void beforeEach(){
		System.out.println("Before each called ");
		collection.add(new SavingAccount("Ajit", 100000));
		System.out.println(collection.findAll());
		System.out.println("Before Each Ending ");
	}

	@AfterEach
	void afterEach() {
		System.out.println("After Each Test");
		System.out.println("Remove updates done on current object undertest ");
		collection.findAll().remove(new SavingAccount("Ajit", 100000));
	}

	@Test
	void testAddAccount() {
		System.out.println("testAddAccount()");
		String actual=collection.add(new SavingAccount("Ajit", 100000));//2
		String exptected="CREATED";
		assertEquals(exptected, actual);
	}
	@Test
	void testAddDuplicateAccount() {
		System.out.println("testAddDuplicateAccount()");
		String actual=collection.add(new SavingAccount(1,"Ajit", 100000));//1
		String exptected="PRESENT";
		assertEquals(exptected, actual);
	}
	
	@Test
	void testFindAll() {
		System.out.println("testFindAll()");
		assertNotEquals(0, collection.findAll().size(),"List have some elements in it ");
		assertNotNull(collection.findAll(),"List is not null");
	}

	@Test
	void testFindByAccNo() {
		System.out.println("testFindByAccNo()");
		assertNotNull(collection.findByAccNo(1),"Account is present");
		assertNull(collection.findByAccNo(0),"Account does not exist");
	}

}
