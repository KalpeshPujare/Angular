package com.mastek.bankapp;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.SalaryAccount;
import com.mastek.bankapp.model.SavingAccount;
import com.mastek.bankapp.service.BankAccountCollection;

public class BankApp {

	public static void main(String[] args) {
		//step1 : Create Account		
		BankAccount account1=new SavingAccount("Jatin",111111);
		BankAccount account2=new SalaryAccount("Nitin",111112);		
		BankAccount account3=new SavingAccount("Putin",111113);
		BankAccount account4=new SalaryAccount("katin",111114);		
		BankAccount account5=new SavingAccount("Ajit" ,111115);
		BankAccount account6=new SalaryAccount("Sujit",111116);		
		
		BankAccountCollection collection=new BankAccountCollection();
		collection.add(account1);
		collection.add(account2);
		collection.add(account3);
		collection.add(account4);
		collection.add(account5);
		collection.add(account6);
				
//		Set<BankAccount> setOfAccount=(Set<BankAccount>) collection.findAll();
//		print(listOfAccount);
//
//		//Collection Collections.java->sort/searching
//		Collections.sort(listOfAccount);//Comparable		
//		//You present BankAccount in Ascending order of accName		
//		Collections.sort(listOfAccount,new Comparator<BankAccount>() {
//			@Override
//			public int compare(BankAccount o1, BankAccount o2) {
//				
//				return o1.getAccName().compareTo(o2.getAccName());
//			}
//		});		
//		System.out.println("Asc Name");
//		print(listOfAccount);
//		//You present BankAccount in Descending order of accName		
//		Collections.sort(listOfAccount,new Comparator<BankAccount>() {
//			@Override
//			public int compare(BankAccount o1, BankAccount o2) {
//				
//				return o2.getAccName().compareTo(o1.getAccName());
//			}
//		});		
//		System.out.println("Desc Name");
//		print(listOfAccount);
		//Using Java8 Feature Lambda Expression 
		//1. iterator over a list using lambda
//		System.out.println("Method 1");
//		listOfAccount.forEach(System.out::println);	//System.out.println(account)
//		System.out.println("Method 2");
//		listOfAccount.forEach(account->System.out.println(account));
//		System.out.println("Sort By name asc");
//		Collections.sort(listOfAccount,(acc1,acc2)->{
//			return acc1.getAccName().compareTo(acc2.getAccName());
//		});
//		listOfAccount.forEach(System.out::println);
//		System.out.println("Sort By name desc");
//		Collections.sort(listOfAccount,(acc1,acc2)->{
//			return acc2.getAccName().compareTo(acc1.getAccName());
//		});
//		listOfAccount.forEach(System.out::println);
//		System.out.println("Sort By balance asc");
//		Collections.sort(listOfAccount,(acc1,acc2)->{
//			return (int) (acc1.getBalance()-acc2.getBalance());
//		});
//		listOfAccount.forEach(System.out::println);
//		System.out.println("Sort By balance desc");
//		Collections.sort(listOfAccount,(acc1,acc2)->{
//			return (int) (acc2.getBalance()-acc1.getBalance());
//		});
//		listOfAccount.forEach(System.out::println);
//		
//	}

	private static void print(List<BankAccount> listOfAccount) {
		for(BankAccount account:listOfAccount) {
			System.out.println(account);
		}
	}

	

}