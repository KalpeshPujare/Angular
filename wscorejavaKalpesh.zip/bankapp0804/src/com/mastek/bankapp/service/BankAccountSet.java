package com.mastek.bankapp.service;

import java.util.HashSet;

import com.mastek.bankapp.model.BankAccount;

public class BankAccountSet {
	private static  HashSet<BankAccount> hashbankaccount = new HashSet<BankAccount>();
	public String add(BankAccount account) {
		
		hashbankaccount.add(account);
		return "CREATED";

	}
	public HashSet<BankAccount> findAll() {
		
		return  hashbankaccount;
	}

	public BankAccount findByAccNo(int accNo) {
		for(BankAccount account:hashbankaccount) {
			if(account.getAccNo()==accNo)
				return account;
		}
		return null;
		
	}
}