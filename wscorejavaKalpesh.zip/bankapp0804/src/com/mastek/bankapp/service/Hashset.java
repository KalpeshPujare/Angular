package com.mastek.bankapp.service;

import java.util.HashSet;
import java.util.List;

import com.mastek.bankapp.model.BankAccount;

public interface Hashset<BankAccount> {

	 
    String add(BankAccount account);
    HashSet<BankAccount> findAll();
    BankAccount findByAccNo(int accNo);


}
