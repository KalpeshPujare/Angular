package com.mastek.designpattern;

import java.sql.Connection;
import java.sql.SQLException;

import com.mastek.designpattern.factory.ConnectionFactory;
import com.mastek.designpattern.model.DBConnection;

public class Main {

	public static void main(String[] args) {
		String url="jdbc:mysql://localhost:3306/mastekdb";
		String user_name="root";
		String password="root";
		String driverName="com.mysql.jdbc.Driver";
		System.out.println("First time");
		ConnectionFactory factory=
				ConnectionFactory.configure(url, user_name, password, driverName);
		DBConnection dbConnection=null;
		Connection connection=null;
		dbConnection=factory.build();
		try {
			System.out.println("1st ConnectionFactory : "+factory.hashCode());
			connection=dbConnection.getConnection();
			System.out.println("First block ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Second time ");
		factory=
				ConnectionFactory.configure(url, user_name, password, driverName);
		dbConnection=factory.build();
		try {
			System.out.println("2nd ConnectionFactory : "+factory.hashCode());
			connection=dbConnection.getConnection();
			System.out.println("First block ");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}