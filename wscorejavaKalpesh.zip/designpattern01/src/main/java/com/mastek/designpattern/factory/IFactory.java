package com.mastek.designpattern.factory;

public interface IFactory<T> {
	
	T build();
	

}
