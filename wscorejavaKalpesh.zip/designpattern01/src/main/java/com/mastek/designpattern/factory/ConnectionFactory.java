
package com.mastek.designpattern.factory;

import com.mastek.designpattern.model.DBConnection;

public class ConnectionFactory implements IFactory<DBConnection>{	
	private String url;
	private String user_name;
	private String password;
	private String driverName;
	private static ConnectionFactory factory;	
	private ConnectionFactory() {}	
	private ConnectionFactory(String url, String user_name,
			String password, String driverName) {
		super();
		this.url = url;
		this.user_name = user_name;
		this.password = password;
		this.driverName = driverName;
	}
	public DBConnection build() {
		return new DBConnection(this.url, this.user_name,this.password, this.driverName);
	}
	public static ConnectionFactory configure(String url, String user_name, String password,
			String driverName){
			if(factory==null) {
				synchronized (ConnectionFactory.class) {
					if(factory==null) {
						factory=new ConnectionFactory(url,user_name,password,driverName);
					}					
				}				
			}				
		return factory;
	}
	
}
	