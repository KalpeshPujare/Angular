package com.mastek.designpattern.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	private String url;
	private String user_name;
	private String password;
	private String driverName;
	public DBConnection(String url, String user_name, String password, String driverName) {
		super();
		this.url = url;
		this.user_name = user_name;
		this.password = password;
		this.driverName = driverName;
	}
	
	public Connection getConnection() throws SQLException{
		return DriverManager.getConnection(this.url,this.user_name,this.password);
		
	}
	
	
	
}
