package com.mastek.bankapp.model;

import com.mastek.bankapp.util.InsufficientBalanceException;

public class SalaryAccount extends BankAccount{
	private static final double MIN_BALANCE=0.00;

	public SalaryAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SalaryAccount(int accNo, String accName, double balance) {
		super(accNo, accName, balance);
		// TODO Auto-generated constructor stub
	}
	public double withdraw(double amount ) throws InsufficientBalanceException{
		return super.withdraw(amount);
	}
}
