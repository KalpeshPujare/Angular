package com.mastek.bankapp;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.SavingAccount;
import com.mastek.bankapp.util.InsufficientBalanceException;

//ctrl+f11    -    execute
//ctrl+shift+s- to save all
public class BankApp {

	public static void main(String[] args) {

		BankAccount [] accounts=new BankAccount[2];
		accounts[0]=new SavingAccount(1001,"ajit",20_000.00);
		accounts[0]=new SavingAccount(1001,"ajit",20_000.00);
		double amount=19990;
		for(int i=0;i<=accounts.length;i++) {
		try {
			System.out.println("calling withdraw on ajits saving account");
			System.out.println("withdraw 19990");
			accounts[i].withdraw(amount);
//			System.out.println("calling withdraw on sujits salary account");
//			System.out.println("withdraw 19990");
//			accounts[1].withdraw(amount);
			
		}catch(InsufficientBalanceException e){
			System.out.println("For"+ accounts[i].getAccName());
			e.printStackTrace();
			
		}finally {
			System.out.println("Available Balance in Ajit's account"+accounts[0].getBalance());
			System.out.println("Available Balance in Sujit's account"+accounts[1].getBalance());
			
			
			}
		}
	}

}
