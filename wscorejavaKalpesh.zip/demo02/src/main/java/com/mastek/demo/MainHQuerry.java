package com.mastek.demo;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mastek.demo.model.Location;
import com.mastek.demo.util.HibernateUtil;

public class MainHQuerry {

	public static void main(String[] args) {
		
		//working with HQL
		Session session=HibernateUtil.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		
		//1. from claus example
		String query_1="from Location";
		Query<Location> query=session.createQuery(query_1);
		List<Location> list=query.getResultList();
		list.forEach(System.out::println);
		
		//2. select with from
		final String query_2="select location.id, location.name from Location location";
//		System.out.println("Using"+query_2);
//		Query<Location> query2=session.createQuery(query_2);
//		list=query2.getResultList();
//		list.forEach(System.out::println);
		
		//Above Code gives exception as 
				System.out.println("Using "+query_2);
				Query<Object> query2=session.createQuery(query_2);
				List<Object> listObj=query2.getResultList();

				listObj.forEach(System.out::println);
				
				
		
		//3. from select and where clause
		
		final String query_3="select location from Location location where location.name='Mastek'";
		System.out.println("Using"+query_3);
		Query<Location> query3=session.createQuery(query_3);
		list=query3.getResultList();
		list.forEach(l->{System.out.println(l.getId()+" "+l.getName());});
		
	}

}
