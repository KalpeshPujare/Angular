package com.mastek.demo;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mastek.demo.model.Location;
import com.mastek.demo.util.HibernateUtil;

public class Main {
	public static void main(String[] args) {
		try {
			
			Location location1=new Location("Mastek","MBP GHANSOLI");
			Location location2=new Location("Mastek","Seepz");
			Location location3=new Location(1,"Mastek","BPO MBP Ghansoli");
			//1. Persist demo
			Session session =HibernateUtil.getCurrentSession();
			Transaction transaction=session.beginTransaction();
			session.persist(location1);//jpa -ejb3
			transaction.commit();
			
			//2. saveorupdate
			session =HibernateUtil.getCurrentSession();
			transaction=session.beginTransaction();
			System.out.println(session.save(location2)+" created ");
			transaction.commit();
			
			session =HibernateUtil.getCurrentSession();
			transaction=session.beginTransaction();			
			System.out.println("Before saveOrupdate : "+session.get(Location.class, 1));
			transaction.commit();
			
			session =HibernateUtil.getCurrentSession();
			transaction=session.beginTransaction();
			session.saveOrUpdate(location3);
			transaction.commit();
			
			//3. get demo
			session =HibernateUtil.getCurrentSession();
			transaction=session.beginTransaction();
			System.out.println("Before saveOrupdate : "+session.get(Location.class, 1));
			System.out.println("Before saveOrupdate : "+session.get(Location.class, 2));
			//4. load
			System.out.println("Before saveOrupdate : "+session.load(Location.class, 1));
			//5. HQL query
			System.out.println("Display all Records from database ");
			Query<Location> query=session.createQuery("from Location location");
			List<Location>  locationList=query.getResultList();			
			transaction.commit();
			
			//6. Criteria			
			session.close();			
			locationList.forEach(System.out::println);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
				
	}

}