package com.mastek.bankapp;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mastek.demo.model.BankAccount;
import com.mastek.demo.model.SalaryAccount;
import com.mastek.demo.model.SavingAccount;
import com.mastek.demo.util.HibernateUtil;

public class MainTPCH {

	public static void main(String[] args) {
		
		BankAccount ba1=new BankAccount(1001,"Lavanya", 1000.00);
		BankAccount ba2=new SavingAccount(1002,"kalpesh", 100.00);
		BankAccount ba3=new SalaryAccount(1003,"Rohit", 100000.00);
		
		Session session=HibernateUtil.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		session.save(ba1);
		session.save(ba2);
		session.save(ba3);
		transaction.commit();
		session.close();
		
		

	}

}
