package com.mastek.insurance.model;

import java.time.LocalDate;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="CI_TCPH")
@DiscriminatorValue("CI")
public class CarInsurance extends Insurance {
	
	
	private String insuranceType="HomeInsurance";
	
	private String brand;
	private String model;
	private LocalDate purchaseDate;

	public CarInsurance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CarInsurance(int insuranceId, String holderName, int amount, String brand, String model,
			LocalDate purchaseDate) {
		super(insuranceId, holderName, amount);
		this.brand = brand;
		this.model = model;
		this.purchaseDate = purchaseDate;
	}

	
	

}
