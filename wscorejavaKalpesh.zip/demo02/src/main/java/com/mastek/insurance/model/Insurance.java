package com.mastek.insurance.model;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;



@Entity
@Table(name="I_TCPH")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
@DiscriminatorValue("I")
public class Insurance {
	
	@Id
	private int insuranceId;
	private String holderName;
	private int amount;
	public Insurance() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Insurance(int insuranceId, String holderName, int amount) {
		super();
		this.insuranceId = insuranceId;
		this.holderName = holderName;
		this.amount = amount;
	}
	public int getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(int insuranceId) {
		this.insuranceId = insuranceId;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + insuranceId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Insurance other = (Insurance) obj;
		if (insuranceId != other.insuranceId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Insurance [insuranceId=" + insuranceId + ", holderName=" + holderName + ", amount=" + amount + "]";
	} 
	
	
	

}
