package com.mastek.insurance.model;

import java.time.LocalDate;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("HI")
public class HomeInsurance extends Insurance {
	
	private String insuranceType="HomeInsurance";
	
	private String residenceType;
	private double area;
	private LocalDate registrationDate;

	public HomeInsurance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HomeInsurance(int insuranceId, String holderName, int amount, String residenceType, double area,
			LocalDate registrationDate) {
		super(insuranceId, holderName, amount);
		this.residenceType = residenceType;
		this.area = area;
		this.registrationDate = registrationDate;
	}

	
	

}
