package com.mastek.insurance;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.mastek.demo.util.HibernateUtil;
import com.mastek.insurance.model.CarInsurance;
import com.mastek.insurance.model.HomeInsurance;
import com.mastek.insurance.model.Insurance;



public class MainTPCH {

	public static void main(String[] args) {
		
		Insurance i1=new Insurance(1004,"kalpesh",1000);
		Insurance ci2=new CarInsurance(1002,"rohit",20000,"Tata","Nexa", LocalDate.now());
		Insurance hi3=new HomeInsurance(1003,"CRick",30000,"Hotel",2000, LocalDate.now());
		
		Session session=HibernateUtil.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		session.save(i1);
		session.save(ci2);
		session.save(hi3);
		transaction.commit();
		session.close();

	}

}
