package com.mastek.bankapp.util;

public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
