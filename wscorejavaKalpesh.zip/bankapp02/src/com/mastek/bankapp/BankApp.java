package com.mastek.bankapp;

import java.util.Scanner;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.util.InsufficientBalanceException;

public class BankApp {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		while(true) {

			BankAccount account=new BankAccount(1001,"Aditya",20000.00);
			System.out.println("Withdraw 10000.00");
			try {
				System.out.println("Current Balance "+account.withdraw(10000.00));
			} catch (InsufficientBalanceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				System.out.println("First Finally Block called ");
			}
			System.out.println("Withdraw 15000.00");
			try {
				System.out.println("Current Balance "+account.withdraw(15000.00));
			} catch (InsufficientBalanceException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				System.out.println("Second Finally Block called ");
			}
			System.out.println("Do you want to continue y/n");
			final String choice=scanner.nextLine();
			if(choice.equalsIgnoreCase("n")) {
				break;
			}
		}
	}

}