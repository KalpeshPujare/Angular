package com.mastek.imsapp;
import java.util.Scanner;

public class ImsApp {
	
	private static ImsApp[] products= new ImsApp[3];

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		
	}

}
