package com.mastek.imsapp.model;

public class ImsProduct {
			private int pid;
			private String pname;
			private int inStockQuantity;
			//default constructor
			public ImsProduct() {
				super();
				}
			//overload alt s a
			public ImsProduct(int pid, String pname, int inStockQuantity) {
				super();
				this.pid = pid;
				this.pname = pname;
				this.inStockQuantity = inStockQuantity;
			}
			//getter setter alt s r
			public int getPid() {
				return pid;
			}
			public void setPid(int pid) {
				this.pid = pid;
			}
			public String getPname() {
				return pname;
			}
			public void setPname(String pname) {
				this.pname = pname;
			}
			public int getInStockQuantity() {
				return inStockQuantity;
			}
			public void setInStockQuantity(int inStockQuantity) {
				this.inStockQuantity = inStockQuantity;
			}
			//to string alt s s s
			@Override
			public String toString() {
				return "ImsProduct [pid=" + pid + ", pname=" + pname + ", inStockQuantity=" + inStockQuantity + "]";
			}
			//business logic
			
			
			
			
}
