package filebasic.decorator.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestBufferedReader {

	public static void main(String[] args) {
		try {
			File file=new File("bufferedRead.txt");
			FileReader fr=new FileReader(file);
			BufferedReader reader=new BufferedReader(fr);
			String readData=reader.readLine();
			while(readData!=null) {
				System.out.println(readData);
				readData=reader.readLine();
				
			}
			reader.close();
			fr.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
