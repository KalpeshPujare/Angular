package fileiobasic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class TestFIS {

	public static void main(String[] args) {
		try {
			File file = new File("myByte.txt");
			FileInputStream fis = new FileInputStream(file);
			int readData=fis.read();
			while(readData!=1) {
				System.out.println(readData);
				readData=fis.read();
			}
			System.out.println("end of file");
			fis.close();
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
 
	}

}
