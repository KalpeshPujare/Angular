package fileiobasic.serialization.custom;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import fileiobasic.serialization.writer.Product;

public class TestItem {

	public static void main(String[] args) {
		
		final File file=new File("orders");
		Product p1=new Product(1001,"Maza-250ml",20);
		Item item=new Item(p1, 10);
		
		
		try(FileOutputStream fos= new FileOutputStream(file);
				ObjectOutputStream oos=new ObjectOutputStream(fos);
				){
			System.out.println("save to file"+item);
			oos.writeObject(item);
			
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
	//Reading Object from file
		try(FileInputStream fis=new FileInputStream(file);
				ObjectInputStream ois=new ObjectInputStream(fis);) {

			Object someObject=ois.readObject();
			System.out.println(someObject);
			
			
		} catch (Exception e) {
			e.printStackTrace();

		};
		

	}

}
