package fileiobasic.serialization.custom;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import fileiobasic.serialization.writer.Product;

public class Item implements Serializable {
	
	private static final long serialVersionUID=1L;
	private Product product;
	private int quantity;
	private transient double total_item_price;
	
	public Item() {
		super();
	}
	
	

	public Item(Product product, int quantity) {
		super();
		this.product = product;
		this.quantity = quantity;
		this.total_item_price = this.quantity*product.getPrice();
	}



	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setTotal_item_price(double total_item_price) {
		this.total_item_price = total_item_price;
	}
	

	public double getTotal_item_price() {
		return total_item_price;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Item [product=" + product + ", quantity=" + quantity + ", total_item_price=" + total_item_price + "]";
	}
	private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
		ois.defaultReadObject();
		double hiddenValue=ois.readDouble();
		this.total_item_price=hiddenValue;
	}
	
	
	private void writeObject(ObjectOutputStream oos) throws IOException{
		oos.defaultWriteObject();
		oos.writeDouble(this.total_item_price);
	}
	
	
}
