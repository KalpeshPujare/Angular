package fileiobasic.serialization.custom;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.List;

public class Order implements Externalizable {
	private static final long serialVersionUID=1L;
	private int orderId;
	private  List<Item> itemList=new ArrayList<>();
	private double total_order_cost;
	private double discount;
	
	
	
	public Order(int orderId, List<Item> itemList, double discount) {
		super();
		this.orderId = orderId;
		this.itemList = itemList;
		this.discount = discount;
		calTotal_order_cost();
	}


	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<Item> getItemList() {
		return itemList;
	}

	public double getTotal_order_cost() {
		return total_order_cost;
	}
	
	private void calTotal_order_cost() {
//		int sum=0;
//		for(Item item:itemList) {
//			sum=sum+item.getTotal_item_price();
//			
//		}
		this.total_order_cost=itemList.stream().mapToDouble(item->item.getTotal_item_price()).sum();
		
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + orderId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (orderId != other.orderId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", itemList=" + itemList + ", total_order_cost=" + total_order_cost
				+ ", discount=" + discount + "]";
	}

	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		this.orderId=in.readInt();
		this.itemList=(List<Item>)in.readObject();
		this.discount=in.readDouble();
		this.total_order_cost=in.readDouble();
		

	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		//as we deal with objectOutput will work individual object
		out.writeInt(this.orderId);
		out.writeObject(this.itemList);
		out.writeDouble(this.discount);
		out.writeDouble(this.total_order_cost);

	}

}
