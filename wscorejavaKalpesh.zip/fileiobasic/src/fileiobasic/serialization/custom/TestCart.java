package fileiobasic.serialization.custom;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import fileiobasic.serialization.writer.Product;

public class TestCart {

	public static void main(String[] args) {
		Product p1=new Product(1001,"Pepsi-250ml",20);
		Product p2=new Product(1002,"Maaza-250ml",20);
		Product p3=new Product(1003,"Sprite-250ml",20);

		Item item1=new Item(p1, 10);
		Item item2=new Item(p2, 10);
		Item item3=new Item(p3, 10);
		List<Item> listOfItems=new ArrayList<>();
		listOfItems.add(item1);//200
		listOfItems.add(item2);//200
		listOfItems.add(item3);//200
		
		Order order1=new Order(1,listOfItems,0.0);//600
		System.out.println("Before Serialization : \n"+order1);
		File file=new File("orders.data");
		try (FileOutputStream fos=new FileOutputStream(file);
				ObjectOutputStream oos=new ObjectOutputStream(fos);){
			oos.writeObject(order1);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try (FileInputStream fis=new FileInputStream(file);
				ObjectInputStream ois=new ObjectInputStream(fis);){
			Order myorder=(Order)ois.readObject();
			System.out.println("After deserialization : \n"+myorder);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

}
