package fileiobasic.serialization.writer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.HashSet;

public class TestSerialization {

	public static void main(String[] args) {
		//step1:
		File file = new File("product.ser");
		Product p1=new Product(1001,"MAzza-250ml",20.0);
		Product p2=new Product(1002,"MAzza-250ml",40.0);
		Product p3=new Product(1003,"MAzza-250ml",70.0);
		try(
				//step2:
				FileOutputStream fos = new FileOutputStream(file);
				//step3:
				ObjectOutputStream oos = new ObjectOutputStream(fos);
				) {
			System.out.println(" Writing object to file ");
			HashSet<Product> setOfProducts=new HashSet<>();
			setOfProducts.add(p1);
			setOfProducts.add(p2);
			setOfProducts.add(p3);
			System.out.println("Object is Saves!");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}

	}

}
