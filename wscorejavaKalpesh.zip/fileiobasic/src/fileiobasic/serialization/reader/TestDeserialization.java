package fileiobasic.serialization.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Set;

import fileiobasic.serialization.writer.Product;

public class TestDeserialization {

	public static void main(String[] args) throws ClassNotFoundException {
		
		File file=new File("product.ser");
		try (FileInputStream fis=new FileInputStream(file);
				ObjectInputStream ois=new ObjectInputStream(fis);)
			 {
				Set<Product> setOfProducts=(Set<Product>)ois.readObject();
				setOfProducts.forEach(System.out::println);
				
			} catch (IOException e) {
					e.printStackTrace();
			}
			
		}
}
		

	


