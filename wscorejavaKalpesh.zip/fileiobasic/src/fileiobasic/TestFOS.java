package fileiobasic;

import java.io.File;
import java.io.FileOutputStream;

public class TestFOS {

	public static void main(String[] args) {
		
		final boolean appendData=true;
		
		try {
			File file = new File("myByte.txt");
			FileOutputStream fos = new FileOutputStream(file,appendData);

			for (int i = 1; i <= 100; i++) {
				fos.write(i);
			} 
			System.out.println("Data Written to file!");
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
