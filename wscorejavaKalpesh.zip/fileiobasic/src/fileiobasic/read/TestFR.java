package fileiobasic.read;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TestFR {

	public static void main(String[] args) {
		
		try {
			File file=new File("charstream.txt");
			FileReader reader=new FileReader(file);
			
			
			
			reader.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
			
		}

	}

}
