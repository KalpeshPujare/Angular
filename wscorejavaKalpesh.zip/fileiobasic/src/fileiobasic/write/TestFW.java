package fileiobasic.write;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TestFW {

	public static void main(String[] args) {
		
		try {
			File file=new File("charstream.txt");
			FileWriter writer=new FileWriter(file);
			writer.write("Demo to write stream of characters to a file");
			writer.close();;
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
