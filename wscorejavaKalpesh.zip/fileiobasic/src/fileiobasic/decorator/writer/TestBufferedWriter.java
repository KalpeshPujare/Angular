package fileiobasic.decorator.writer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TestBufferedWriter {

	public static void main(String[] args) {
		
		try {
			File file=new File("bufferedRead.txt");
			FileWriter fw=new FileWriter(file);
			BufferedWriter writer=new BufferedWriter(fw);
			for(int i=1;i<11;i++) {
				writer.write(i+" welcome to buffered writer\n ");
			}
			writer.close();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		

	}

}
