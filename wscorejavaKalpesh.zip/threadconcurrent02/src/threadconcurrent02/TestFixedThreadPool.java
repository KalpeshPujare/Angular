package threadconcurrent02;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestFixedThreadPool {

	public static void main(String[] args) {
		System.out.println("Demo of Fixed Thread Pool");
		ExecutorService executor=Executors.newFixedThreadPool(4);
		//Assign Task
		executor.execute(new TaskA("*"));
		executor.execute(new TaskA("#"));
		executor.execute(new TaskA("$"));
		executor.execute(new TaskA("%"));
		executor.execute(new TaskA("@"));
		executor.execute(new TaskA("1"));
		executor.execute(new TaskA("2"));
		System.out.println("Line 19");
		
		
		List<Runnable> runnable=executor.shutdownNow();
		runnable.forEach(System.out::println);
		
		
	//after shutdown don't call the task it will give error
	//executor.execute(new TaskA("2"));
		System.out.println("Line 21");
	}

}
