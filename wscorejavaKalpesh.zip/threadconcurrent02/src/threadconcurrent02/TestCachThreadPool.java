package threadconcurrent02;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestCachThreadPool {

	public static void main(String[] args) {
		
		ExecutorService executor=Executors.newCachedThreadPool();//it create thread same as task available
		executor.execute(new TaskA(" 1 "));
		executor.execute(new TaskA(" 2 "));
		executor.execute(new TaskA(" 3 "));
		executor.execute(new TaskA(" 4 "));
		executor.execute(new TaskA(" 5 "));
		executor.execute(new TaskA(" 6 "));
		executor.execute(new TaskA(" 7 "));
		executor.execute(new TaskA(" 8 "));
		
		executor.shutdown();
		

	}

}
