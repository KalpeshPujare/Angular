package threadconcurrent02;

import java.util.concurrent.TimeUnit;

public class TaskA implements Runnable {
	
	private String msg;
	public TaskA(String msg) {
		this.msg=msg;
	}

	@Override
	public void run() {
		String name=Thread.currentThread().getName();
		
		for(int i=1;i<10;i++) {
			System.out.println(name+"-"+msg);
			try {
				TimeUnit.MILLISECONDS.sleep(10);
			} catch (InterruptedException e) {
				
				new RuntimeException(e.getMessage());
			}
		}

	}

}
