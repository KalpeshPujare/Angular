package threadconcurrent02;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestSingleThreadPool {

	public static void main(String[] args) {
		ExecutorService executor=Executors.newSingleThreadExecutor();//used to complete task in sequence
		
		executor.execute(new TaskA(" 1 "));
		executor.execute(new TaskA(" 2 "));
		executor.execute(new TaskA(" 3 "));
		executor.execute(new TaskA(" 4 "));
		executor.execute(new TaskA(" 5 "));
		executor.execute(new TaskA(" 6 "));
		executor.execute(new TaskA(" 7 "));
		executor.execute(new TaskA(" 8 "));
		
		executor.shutdown();
		

	}

}
