package callabledemo;

import java.util.concurrent.Callable;

public class MyCaller implements Callable<Integer> {

	@Override
	public Integer call() throws Exception {
		
		String name=Thread.currentThread().getName();
		for(int i=0;i<10;i++) {
			System.out.println(" called "+i+" by "+name);
		
		}
			return 1000;
		}
		
	}
	
	


