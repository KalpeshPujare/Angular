package threadBasic01;

import java.util.concurrent.TimeUnit;

public class TestThread01 {

	public static void main(String[] args) {
		//step1: using annonymous Thread class
		Thread th=new Thread() {
			public void run(){
				for(int i=0;i<10;i++) {
					//using thread sleep method to interrupt
					//old way to sleep a thread
					//Thread.sleep(1000);
					//new way
					try {
						TimeUnit.MILLISECONDS.sleep(1000);
						System.out.println(Thread.currentThread().getName()+
						"\t"+Thread.currentThread().isInterrupted()
						);
						
					}catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		th.start();
		th.start();

	}


}