package threadBasic01;

import java.util.concurrent.TimeUnit;

public class MyThread extends Thread {
	
	@Override
	public void run() {
		String name=Thread.currentThread().getName();
		while(true) {
			if(isDaemon())
			System.out.println(name+" is Daemon ");
			else
				System.out.println(name);
			try {
				TimeUnit.MILLISECONDS.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
