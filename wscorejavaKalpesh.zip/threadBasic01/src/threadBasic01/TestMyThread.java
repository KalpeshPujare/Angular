package threadBasic01;

public class TestMyThread {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName()+"Started");
		MyThread th1=new MyThread();
		MyThread th2=new MyThread();
		MyThread th3=new MyThread();
		
		th1.setDaemon(true);
		th2.setDaemon(true);
		th3.setDaemon(true);
		
		th1.start();
		th2.start();
		th3.start();
		System.out.println(Thread.currentThread().getName()+"completed all task waiting");


	}

}
