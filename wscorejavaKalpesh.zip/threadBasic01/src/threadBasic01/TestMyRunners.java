package threadBasic01;

public class TestMyRunners {

	public static void main(String[] args) {
		
		MyRunners runner1=new MyRunners();
		MyRunners runner2=new MyRunners();
		MyRunners runner3=new MyRunners();
		
		
		Thread th1=new Thread(runner1,"Th1");
		Thread th2=new Thread(runner2,"Th2");
		Thread th3=new Thread(runner3,"Th3");
		
		th1.setDaemon(true);
		
		th1.start();
		th2.start();
		th3.start();
		

	}

}
