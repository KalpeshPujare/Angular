package threadBasic01;

public class TestMainThread {

	public static void main(String[] args) {
		Thread thread=Thread.currentThread();
		System.out.println("Name   "+thread.getName());
		System.out.println("Id   "+thread.getId());
		System.out.println("Priority   "+thread.getPriority());
		System.out.println("IsAlive   "+thread.isAlive());
		System.out.println("IsDaemon   "+thread.isDaemon());
		System.out.println("IsInterrupted   "+thread.isInterrupted());
		System.out.println("Max   "+thread.MAX_PRIORITY);
		System.out.println("Min   "+thread.MIN_PRIORITY);
		System.out.println("Norm   "+thread.NORM_PRIORITY);

	}

}
