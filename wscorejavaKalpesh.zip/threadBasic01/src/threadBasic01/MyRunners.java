package threadBasic01;

import java.util.concurrent.TimeUnit;

public class MyRunners implements Runnable {

	@Override
	public void run() {
		String name=Thread.currentThread().getName();
		String msg="";
		while(true) {
			if(Thread.currentThread().isDaemon()){
				msg=" is daemon ";
			}
			System.out.println(name+msg);
			try {
				TimeUnit.MILLISECONDS.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
