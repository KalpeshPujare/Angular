package com.mastek.bankapp.model;

import com.mastek.bankapp.util.InsufficientBalanceException;

public class SalaryAccount extends BankAccount {

	public SalaryAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SalaryAccount(int accNo, String accName, double balance) {
		super(accNo, accName, balance);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public double withdraw(double amount) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		return super.withdraw(amount);
	}
}
