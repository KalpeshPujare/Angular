package com.mastek.bankapp.util;

public class MaintainMinBalanceException extends InsufficientBalanceException {
	public MaintainMinBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub

}
}
