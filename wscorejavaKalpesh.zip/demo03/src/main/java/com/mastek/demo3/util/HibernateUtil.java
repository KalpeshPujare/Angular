package com.mastek.demo3.util;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HibernateUtil {
	private static SessionFactory sessionFactory = null;
	private static final Logger log = LoggerFactory.getLogger(HibernateUtil.class);

	public static SessionFactory getSessionFactory() {
		if (sessionFactory == null) {
			try {
				final Configuration configuration = new Configuration();
				configuration.configure("hibernate.cfg.xml");
				ServiceRegistry registry = configuration.getStandardServiceRegistryBuilder().build();
				sessionFactory = configuration.buildSessionFactory();
			} catch (HibernateException e) {
				e.printStackTrace();
			}
		}
		return sessionFactory;
	}

	/**
	 * Get the current Hibernate session. This creates a new session if no current
	 * session.
	 * 
	 * @return the current Hibernate Session
	 */
	public static Session getCurrentSession() {
		return getSessionFactory().getCurrentSession();
	}

	/**
	 * Get the session if current session is available
	 * 
	 * @return the current Hibernate Session
	 */
	public static Session openSession() {
		return getSessionFactory().openSession();
	}

}
