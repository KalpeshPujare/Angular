package com.mastek.demo3;

import java.time.LocalDate;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mastek.demo3.model.Event;
import com.mastek.demo3.model.Location;
import com.mastek.demo3.util.HibernateUtil;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
       Location location=new Location(1,"Mastek","Seepz");
       Event event=new Event(1,"MateskDash",LocalDate.now(),location);
       Session session=HibernateUtil.getCurrentSession();
       Transaction transaction=session.beginTransaction();
       
       System.out.println("Adding details of event to database");
       session.persist(event);
       
       System.out.println("Show all records in DB - of Location");
       Query<Location> locations=session.createQuery("from Location");
       locations.getResultStream().forEach(System.out::println);
       
       System.out.println("Show all records in DB - of Event");
       Query<Event> events=session.createQuery("from Event");
       events.getResultStream().forEach(System.out::println);
       
       transaction.commit();
       session.close();
       
    }
}
