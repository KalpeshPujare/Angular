
class BankAccount{ 
	int accNo = 1001; String name = "abc";
public int hashCode(){   return accNo; }
public boolean equals(Object o){
	return (this.hashCode() == o.hashCode());
	}
}