package com.mastek.demo05;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mastek.demo05.model.OrderItems;
import com.mastek.demo05.model.Orders;
import com.mastek.demo05.model.Product;
import com.mastek.demo05.util.HibernateUtil;



public class App {

	public static void main(String[] args) {
		
		Product p1= new Product(1,"Pepsi",20);
		Product p2= new Product(2,"Coke",30);
		Product p3= new Product(3,"Sprite",50);
		
		OrderItems orderItem1= new OrderItems(1,p1,10);
		OrderItems orderItem2= new OrderItems(2,p2,10);
		OrderItems orderItem3= new OrderItems(3,p3,10);
		
		Map<Integer,OrderItems> item=new HashMap<Integer, OrderItems>();
		item.put(orderItem1.getItemId(), orderItem1 );
		item.put(orderItem2.getItemId(), orderItem2);
		item.put(orderItem3.getItemId(), orderItem3);
		
		Orders orders=new Orders(1, LocalDate.now(), item);
		Session session=HibernateUtil.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		System.out.println("Adding details of orders to database");
		session.persist(orders);
		System.out.println("show all records in db");
		
		
		Query<Orders> orderList=session.createQuery("from Orders");
		orderList.getResultStream().forEach(System.out::println);
		
		transaction.commit();
		session.close();
		

	}

}
