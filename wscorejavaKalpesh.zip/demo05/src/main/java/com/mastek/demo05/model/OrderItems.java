package com.mastek.demo05.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class OrderItems {

		@Id
		private int itemId;
		@OneToOne(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
		private Product product;
		private int quantity;
		public OrderItems() {
			super();
			// TODO Auto-generated constructor stub
		}
		public OrderItems(int itemId, Product product, int quantity) {
			super();
			this.itemId = itemId;
			this.product = product;
			this.quantity = quantity;
		}
		public int getItemId() {
			return itemId;
		}
		public void setItemId(int itemId) {
			this.itemId = itemId;
		}
		public Product getProduct() {
			return product;
		}
		public void setProduct(Product product) {
			this.product = product;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + itemId;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			OrderItems other = (OrderItems) obj;
			if (itemId != other.itemId)
				return false;
			return true;
		}
		@Override
		public String toString() {
			return "OrderItems [itemId=" + itemId + ", product=" + product + ", quantity=" + quantity + "]";
		}
		
		
}
