package com.mastek.demo05.model;

public class Customer {

}
