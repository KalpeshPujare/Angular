package com.mastek.demo05.model;

import java.time.LocalDate;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ims_orders")
public class Orders {
	@Id
	private int orderid;
	private LocalDate orderDate;
	
	
	@OneToMany(cascade =CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinTable(name="ims_ordereditems")
	private Map<Integer,OrderItems> items;


	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Orders(int orderid, LocalDate orderDate, Map<Integer, OrderItems> items) {
		super();
		this.orderid = orderid;
		this.orderDate = orderDate;
		this.items = items;
	}


	public int getOrderid() {
		return orderid;
	}


	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}


	public LocalDate getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}


	public Map<Integer, OrderItems> getItems() {
		return items;
	}


	public void setItems(Map<Integer, OrderItems> items) {
		this.items = items;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + orderid;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Orders other = (Orders) obj;
		if (orderid != other.orderid)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Orders [orderid=" + orderid + ", orderDate=" + orderDate + ", items=" + items + "]";
	}

}
