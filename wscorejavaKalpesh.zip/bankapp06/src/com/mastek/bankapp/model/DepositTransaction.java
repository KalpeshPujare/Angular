package com.mastek.bankapp.model;

public interface DepositTransaction {
	
	double deposit(double amount);
	

}
