package com.mastek.bankapp.model;

import com.mastek.bankapp.util.InsufficientBalanceException;

public class Transaction {
	private BankAccount account;
	private double amount;
	private DepositTransaction credit;
	private WithdrawTransaction debit;
	
	public Transaction(BankAccount account) {
		super();
		this.account = account;
	}
	
	public String withdraw(double amount,WithdrawTransaction debit) throws InsufficientBalanceException {
		return amount+" Debited from "+account.getAccNo()+" avialble balance is "+debit.withdraw(amount);
		
	}
	public String deposit(double amount,DepositTransaction credit){
		return amount+" Debited from "+account.getAccNo()+" avialble balance is "+credit.deposit(amount);
		
	}

}
