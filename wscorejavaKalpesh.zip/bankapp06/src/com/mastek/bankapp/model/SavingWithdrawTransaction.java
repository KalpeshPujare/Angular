package com.mastek.bankapp.model;
import com.mastek.bankapp.util.MaintainMinBalanceException;

public class SavingWithdrawTransaction implements WithdrawTransaction{
	
	private BankAccount account;
	
	public SavingWithdrawTransaction(BankAccount account) {
		super();
		this.account = account;
	}
	@Override
	public double withdraw(double amount)throws MaintainMinBalanceException{
		double diff= account.getBalance()-amount;
		if(diff>= ((SavingAccount)account).MIN_BALANCE) {
			account.setBalance(diff);
			
		}else{
			throw new MaintainMinBalanceException("Must maintain 1000.00 MinBalance");
		}
		return account.getBalance();
		
	}
	
}
