package com.mastek.bankapp.model;

public abstract class BankAccount {
	private int accNo;
	private String accName;
	protected double balance;
	//default constructor
	public BankAccount() {
		super();
		
	}
	//overload alt s a
	public BankAccount(int accNo, String accName, double balance) {
		super();
		this.accNo = accNo;
		this.accName = accName;
		this.balance = balance;
	}
	//getter alt s r
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public String getAccName() {
		return accName;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	//tostring() alt s s s
	@Override
	public String toString() {
		return "BankAccount [accNo=" + accNo + ", accName=" + accName + ", balance=" + balance + "]";
	}
	// Business Logic
	
	
//	public double deposit(double amount)throws InsufficientBalanceException{
//		this.balance= this.balance+amount;
//		return getBalance();
//	}
//
//	//to import all classes from the other package shortcut : ctrl shift o
//	public abstract double withdraw(double amount)throws InsufficientBalanceException;

}


