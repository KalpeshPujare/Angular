package com.mastek.bankapp.model;

public class SavingAccount extends BankAccount {
	public static final double MIN_BALANCE = 1000.0;

	public SavingAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SavingAccount(int accNo, String accName, double balance) {
		super(accNo, accName, balance);
		// TODO Auto-generated constructor stub
	}
//	@Override
//	public double withdraw(double amount)throws MaintainMinBalanceException{
//		double diff= this.balance-amount;
//		if(diff>= MIN_BALANCE) {
//			this.setBalance(diff);
//			
//		}else{
//			throw new MaintainMinBalanceException("Must maintain 1000.00 MinBalance");
//		}
//		return getBalance();
//		
//	}

}
