package com.mastek.bankapp.model;

import com.mastek.bankapp.util.InsufficientBalanceException;

public class SalaryWithdrawTransaction implements WithdrawTransaction {
private BankAccount account;
	
	public SalaryWithdrawTransaction(BankAccount account) {
		super();
		this.account = account;
	}
	@Override
	public double withdraw(double amount) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		double diff=account.getBalance()-amount;
		if (diff>=0) {
			account.setBalance(diff);
		}else {
			throw new InsufficientBalanceException("Insufficient Balance");
		}
		return account.getBalance();
	}

}
