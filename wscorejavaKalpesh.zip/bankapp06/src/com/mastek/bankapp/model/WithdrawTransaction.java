package com.mastek.bankapp.model;

import com.mastek.bankapp.util.InsufficientBalanceException;

public interface WithdrawTransaction {
	double withdraw(double amount)throws InsufficientBalanceException;

}
