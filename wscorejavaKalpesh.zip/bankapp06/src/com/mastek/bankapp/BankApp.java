package com.mastek.bankapp;

import com.mastek.bankapp.model.BankAccount;
import com.mastek.bankapp.model.SalaryAccount;
import com.mastek.bankapp.model.SalaryWithdrawTransaction;
import com.mastek.bankapp.model.SavingAccount;
import com.mastek.bankapp.model.SavingWithdrawTransaction;
import com.mastek.bankapp.model.Transaction;
import com.mastek.bankapp.util.InsufficientBalanceException;

public class BankApp {

	public static void main(String[] args) {
		BankAccount[] accounts = new BankAccount[2];
		accounts[0] = new SavingAccount(1001, "Ajit", 20_000.00);
		accounts[1] = new SalaryAccount(1002, "Sujit", 20_000.00);
			Transaction transaction1 = new Transaction(accounts[0]);
			String msg="";
			try {
				msg=transaction1.withdraw(1000, new SavingWithdrawTransaction(accounts[0]));
				System.out.println(msg);
			}catch(InsufficientBalanceException e) {
				e.printStackTrace();
				
			}
			transaction1=new Transaction(accounts[1]);
			try {
				msg=transaction1.withdraw(1000, new SalaryWithdrawTransaction(accounts[1]));
				System.out.println(msg);
			}catch(InsufficientBalanceException e) {
				e.printStackTrace();
				
			}
	}

}